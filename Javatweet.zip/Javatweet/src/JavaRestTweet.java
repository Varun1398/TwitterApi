import oauth.signpost.OAuthConsumer;
import oauth.signpost.commonshttp.CommonsHttpOAuthConsumer;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;

public class JavaRestTweet {
	static String consumerKeyStr = "qer6JvuoOOrEZVZM6lgjEdP0T";
	static String consumerSecretStr = "yhrui4vtWuB8hjAbYuyYlCTSG3xubZc0ylToIi65JFoEDVhO6E";
	static String accessTokenStr = "4693974978-DW5KczgJatC6xV10bLmkBjqvFlvw3CrYJg9I2HC";
	static String accessTokenSecretStr = "cel8UNqNYuIJ7SgA4yRWGsFHKenIo25dFSYyKoPlMzBxL";


	public static void main(String[] args) throws Exception {
		OAuthConsumer oAuthConsumer = new CommonsHttpOAuthConsumer(consumerKeyStr,
				consumerSecretStr);
		oAuthConsumer.setTokenWithSecret(accessTokenStr, accessTokenSecretStr);

		HttpPost httpPost = new HttpPost(
				"http://api.twitter.com/1.1/statuses/update.json?status=Hello%20Twitter%20World.");

		oAuthConsumer.sign(httpPost);

		HttpClient httpClient = new DefaultHttpClient();
		HttpResponse httpResponse = httpClient.execute(httpPost);

		int statusCode = httpResponse.getStatusLine().getStatusCode();
		System.out.println(statusCode + ':'
				+ httpResponse.getStatusLine().getReasonPhrase());
		System.out.println(IOUtils.toString(httpResponse.getEntity().getContent()));

	}
}