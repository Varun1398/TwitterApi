package twitter;

import twitter4j.Twitter;
import twitter4j.TwitterException;
import twitter4j.TwitterFactory;
import twitter4j.auth.AccessToken;

public class JavaTweet {

	static String consumerKeyStr = "qer6JvuoOOrEZVZM6lgjEdP0T";
	static String consumerSecretStr = "yhrui4vtWuB8hjAbYuyYlCTSG3xubZc0ylToIi65JFoEDVhO6E";
	static String accessTokenStr = "4693974978-DW5KczgJatC6xV10bLmkBjqvFlvw3CrYJg9I2HC";
	static String accessTokenSecretStr = "cel8UNqNYuIJ7SgA4yRWGsFHKenIo25dFSYyKoPlMzBxL";

	public static void main(String[] args) {

		try {
			Twitter twitter = new TwitterFactory().getInstance();

			twitter.setOAuthConsumer(consumerKeyStr, consumerSecretStr);
			AccessToken accessToken = new AccessToken(accessTokenStr,
					accessTokenSecretStr);

			twitter.setOAuthAccessToken(accessToken);

			twitter.updateStatus("Hey there! I just posetd on twitter using java");

			System.out.println("Successfully updated the status in Twitter.");
		} catch (TwitterException te) {
			te.printStackTrace();
		}
	}

}